﻿CREATE TABLE [dbo].[SignUps]
(
	[Id] INT NOT NULL PRIMARY KEY Identity, 
    [EmployeeId] INT NOT NULL, 
    [FirstName] NVARCHAR(50) NOT NULL, 
    [LastName] NVARCHAR(50) NOT NULL, 
    [EmailAddress] NVARCHAR(MAX) NOT NULL, 
    [Password] NVARCHAR(50) NOT NULL, 
    [ConfirmEmail] NVARCHAR(MAX) NOT NULL, 
    [ConfirmPassword] NVARCHAR(50) NOT NULL
)
