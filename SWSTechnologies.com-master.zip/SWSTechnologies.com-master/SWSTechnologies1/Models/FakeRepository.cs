﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SWSTechnologies1.Models
{
    public class FakeRepository : IContactRepository
    {
        public IQueryable<ContactClientModel> Contact => new List<ContactClientModel> {
            new ContactClientModel { Name = "Dan Leash", EmailAddress = "DAN.LEASH@GMAIL.COM", PhoneNumber = "856-536-2237", Message = "Microsoft pls give me job" },
            new ContactClientModel { Name = "Dan Leash", EmailAddress = "DAN.LEASH@GMAiIL.COM", PhoneNumber = "836-536-2237", Message = "Micrsoft pls give me job"},
            new ContactClientModel { Name = "Dan Leash", EmailAddress = "DAN.LEASH@GMAIL.COM", PhoneNumber = "856-536-2237", Message = "Microsoft pls give me job" }
        }.AsQueryable<ContactClientModel>();
    }
}
