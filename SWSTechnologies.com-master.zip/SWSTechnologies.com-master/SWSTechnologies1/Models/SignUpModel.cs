﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace SWSTechnologies1.Models
{
    public class SignUpModel
    {
        public int Id { get; set; }
        [Range(100, 103, ErrorMessage ="You must enter a valid employee Id number.")]
        [Required(ErrorMessage ="Enter your employee Id.")]
        public int EmployeeId { get; set; }
        [Required(ErrorMessage ="Please enter your first name.")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Please enter your last name.")]

        public string LastName { get; set; }

        [DataType(DataType.EmailAddress)]
        [Required(ErrorMessage ="You need to give us your email address.")]
        public string EmailAddress { get; set; }

        [DataType(DataType.EmailAddress)]
        [Compare("EmailAddress", ErrorMessage = "Your emails must match.")]
        public string ConfirmEmail { get; set; }

        
        [Required(ErrorMessage ="You must have a password.")]
        [DataType(DataType.Password)]
        [StringLength(100, MinimumLength = 8, ErrorMessage ="You need to provide a longer password.")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage ="Your passwords must match.")]
        public string ConfirmPassword { get; set; }
    }
}
